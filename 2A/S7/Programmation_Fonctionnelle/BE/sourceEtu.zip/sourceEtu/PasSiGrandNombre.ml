open GrandNombre

module PasSiGrandNombre : IGrandNombre =
struct
  type t = int
  let from_int n = n
  let from_digits _ _ = failwith "TO DO"

  let afficher x = print_int x
  let comparer a b = compare a b
  let plus = (+)
  let moins = (-)
  let mult a b = a * b
  let puiss _ _ = failwith "TO DO"
end

(* Décommenter pour lancer les tests ! *)
(* module PasSiGrandNombreTest = GrandNombreTest (PasSiGrandNombre) *)
(* module PasSiGrandNombreAlgo = GrandNombreAlgorithmes (PasSiGrandNombre) *)



