#define _GNU_SOURCE
#include "liste_noeud.h"
#include <stdlib.h>
#include <math.h>

/**
 * Cellule d'une liste.
 */
struct _cellule {
    /** Le noeud. */
    noeud_id_t noeud;
    /** Le noeud précédent. */
    noeud_id_t precedent;
    /** La distance. */
    float distance;
    /** Pointeur sur la cellule suivante */
    struct _cellule* suivante;
}

typedef struct _cellule _cellule;

/**
 * Liste de noeuds.
 */
struct liste_noeud_t {
    /* Pointeur sur la première cellule */
    _cellule* premiere;
    /* Pointeur sur la dernière cellule */
    _cellule* derniere;
}


/**
 * creer_liste : crée une liste de noeuds, initialement vide
 *
 * Post-conditions : `r = creer_liste()` => `r != NULL`, `est_vide_liste(r)`
 * @return liste nouvellement créée (de type liste_noeud_t)
 */
liste_noeud_t creer_liste() {
    liste_noeud_t* liste = (liste_noeud_t*)malloc(sizeof(liste_noeud_t));
    if (liste != NULL) {
        liste->premiere = NULL;
        liste->derniere = NULL;
    }
    return liste;
}

/**
 * detruire_liste : détruit la liste passée en paramètre
 *
 * Pré-conditions : liste_ptr != NULL
 * Post-conditions : *liste_ptr == NULL
 *
 * @param liste_ptr pointeur sur la liste à détruire
 */
void detruire_liste(liste_noeud_t** liste_ptr) {
    liste_noeud_t* liste = *liste_ptr;
    if (liste != NULL && *liste != NULL) {
        _cellule* temp = liste_ptr->premiere;
        while (temp != NULL) {
            _cellule* suivante = temp->suivante;
            free(temp);
            temp = suivante;
        }
        liste->premiere=NULL;
        liste->derniere=NULL;
    }
    free(liste);
    free(*liste_ptr);
}
        
/**
 * est_vide_liste : test si la liste passée en paramètre est vide
 *
 * Pré-conditions : liste != NULL
 *
 * @param liste [in] liste à tester
 * @return vrai ssi la liste ne contient aucun élément
 */
bool est_vide_liste(const liste_noeud_t* liste) {
    return liste==NULL || *liste==NULL || (liste->premiere == NULL && liste->derniere == NULL);
}

/**
 * contient_noeud_liste : test si le noeud donné appartient à la liste donnée.
 * 
 * Pré-conditions : liste != NULL
 *
 * @param liste [in] liste à parcourir
 * @param noeud noeud à rechercher
 * @return vrai ssi noeud est dans liste
 */
bool contient_noeud_liste(const liste_noeud_t* liste, noeud_id_t noeud) {
    if (est_vide_liste(liste)) {
        return false;
    }
    _cellule* temp = liste->premiere;
    while (temp!=NULL) {
        if (temp->noeud == noeud) {
            return true;
        }
        temp = temp->suivante;
    }
    return false;
}
    
/**
 * contient_arrete_liste : test si l'arrête donnée appartient à la liste donnée.
 * L'arrête (source, destination) appartient à la liste ssi destination appartient à liste
 * et si prec(destination) == source.
 *
 * Pré-conditions : liste != NULL
 *
 * @param liste [in] liste à parcourir
 * @param source noeud source de l'arrête
 * @param destination noeud destination de l'arrête
 * @return vrai ssi l'arrête (source,destination) est dans liste
 */
bool contient_arrete_liste(const liste_noeud_t* liste, noeud_id_t source, noeud_id_t destination) {
    if (est_vide_liste(liste)) {
        return false;
    }
    if (contient_noeud_liste(liste, destination) && (precedent_noeud_liste(liste, destination) == source)) {
        return true;
    }
    return false;
}

/**
 * distance_noeud_liste : récupère la distance associée au noeud donné dans la liste donnée.
 * Si le noeud n'existe pas dans la liste, retourne `INFINITY`.
 *
 * Pré-conditions : liste != NULL
 * Post-conditions : `contient_noeud_liste(liste, noeud)` <=> `distance_noeud_liste(liste, noeud) != INFINITY`
 *
 * @param liste [in] liste à parcourir
 * @param noeud noeud dont on veut la distance
 * @return distance associée à noeud dans liste ou INFINITY si noeud n'est pas dans liste
 */
float distance_noeud_liste(const liste_noeud_t* liste, noeud_id_t noeud) {
    if (est_vide_liste(liste)) {
        return INFINITY;
    }
    _cellule* temp = liste->premiere;
    while (temp != NULL) {
        if (temp->noeud == noeud) {
            return temp->distance;
        }
        temp = temp->suivante;
    }
    return INFINITY;
}
/**
 * precedent_noeud_liste : récupère le noeud précédent associé au noeud donné dans la liste donnée.
 * Si le noeud n'existe pas, retourne `NO_ID`.
 * 
 * Pré-conditions : liste != NULL
 * Post-conditions : `!contient_noeud_liste(liste, noeud)` => `precedent_noeud_liste(liste, noeud) = NO_ID`
 *
 * @param liste [in] liste à parcourir
 * @param noeud noeud dont on veut le précédent
 * @return précédent associé au noeud dans la liste (ou `NO_ID` si noeud n'est pas dans liste)
 */
noeud_id_t precedent_noeud_liste(const liste_noeud_t* liste, noeud_id_t noeud) {
    if (est_vide_liste(liste)) {
        return NO_ID;
    }
    _cellule* temp = liste->premiere;
    while (temp != NULL) {
        if (temp->noeud == noeud) {
            return temp->precedent;
        }
        temp = temp->suivante;
    }
    return NO_ID;
}

/**
 * min_noeud_liste : trouve le (un) noeud de la liste dont la distance associée est la plus petite,
 * ou renvoie `NO_ID` si la liste est vide.
 *
 * Pré-conditions : liste non NULL
 * Post-conditions : `n = min_noeud_liste(liste) && n != NO_ID` =>
 *   pour tout `n', contient_noeud_liste(liste, n')`, `distance_noeud_liste(liste, n) <= distance_noeud_liste(liste, n')`
 *
 * @param liste [in] liste à parcourir
 * @return noeud qui minimise la distance, ou `NO_ID` si pas de noeud
 */
noeud_id_t min_noeud_liste(const liste_noeud_t* liste) {
    if (est_vide_liste(liste)) {
        return NO_ID;
    }
    _cellule* c_temp = liste->premiere;
    noeud_id_t n_temp;
    float d_temp;
    noeud_id_t n_min = NO_ID;
    float d_min = INFINITY;
    while (c_temp != NULL) {
        n_temp = c_temp->noeud;
        d_temp = distance_noeud_liste(liste, n_temp);
        if (d_temp < d_min) {
            d_min = d_temp;
            n_min = n_temp;
        }
        c_temp = c_temp->suivante;
    }
    return n_min;
}

/**
 * inserer_noeud_liste : insère le noeud donné dans la liste
 *
 * Pré-conditions : liste != NULL
 *
 * @param liste [in,out] liste dans laquelle insérer l'élément
 * @param noeud noeud à insérer (caractérisé par son identifiant)
 * @param precedent noeud précédent du noeud à insérer (prec(n))
 * @param distance distance du noeud à insérer (dist(n))
 */
void inserer_noeud_liste(liste_noeud_t* liste, noeud_id_t noeud, noeud_id_t precedent, float distance) {
    // si la liste contient déjà le noeud, ne rien faire
    if (contient_noeud_liste(iste, noeud) == true) {
        return;
    }
    // sinon, on crée la cellule du noeud à insérer
    _cellule* cellule;
    cellule->noeud = noeud;
    cellule->precedent = precedent;
    cellule->distance = distance;
    cellule->suivante = NULL;
    // si la liste est vide, insérer au début
    if (est_vide_liste(liste)) {
        liste->premiere = cellule;
        liste->derniere = NULL;
        return;
    }
    // sinon insérer au début en mettant à jour premiere
    cellule->suivante = liste->premiere;
    liste->premiere = cellule;
}

/**
 * changer_noeud_liste : modifie les valeurs associées au noeud donné dans la liste donnée.
 * Si le noeud n'est pas dans la liste, il est ajouté.
 *
 * Pré-conditions : liste != NULL
 * Post-conditions :
 *   - `contient_noeud_liste(liste, noeud)`
 *   - `distance_noeud_liste(liste, noeud) == distance`
 *   - `precedent_noeud_liste(liste, noeud) == precedent`
 *
 * @param liste [in,out] liste à modifier
 * @param noeud noeud à modifier
 * @param precedent nouveau noeud précédent pour noeud
 * @param distance nouvelle distance pour noeud
 */
void changer_noeud_liste(liste_noeud_t* liste, noeud_id_t noeud, noeud_id_t precedent, float distance) {
    if (est_vide_liste(liste) || !contient_noeud_liste(iste, noeud)) {
        inserer_noeud_liste(liste, noeud, precedent, distance);
        return;
    }
    _cellule* c_temp = liste->premiere;
    while (c_temp != NULL) {
        if (c_temp->noeud == noeud) {
            c_temp->precedent = precedent;
            c_temp->distance = distance;
            return;
        }
        c_temp = c_temp->suivante;
    }
}

/**
 * supprimer_noeud_liste : supprime le noeud donné de la liste. Si le noeud n'est pas dans la liste,
 * ne fait rien.
 *
 * Pré-conditions : liste != NULL
 * Post-conditions : après `supprimer_noeud_liste(liste, n)` : `!contient_noeud_liste(liste, n)`
 *
 * @param liste [in,out] liste à modifier
 * @param noeud noeud à supprimer de liste
 */
void supprimer_noeud_liste(liste_noeud_t* liste, noeud_id_t noeud) {
    if (est_vide_liste(liste) || !contient_noeud_liste(iste, noeud)) {
        return;
    }
    _cellule* c_temp = liste->premiere;
    while (c_temp != NULL) {
        if (c_temp->noeud == noeud) {
            c_temp = c_temp->suivante;
            return;
        }
        c_temp = c_temp->suivante;
    }
}

