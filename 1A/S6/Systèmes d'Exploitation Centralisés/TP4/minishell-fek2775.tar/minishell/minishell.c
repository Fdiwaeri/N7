#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <unistd.h>     // fork, getpid, getppid
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>    // signal et sigprocmask
#include <fcntl.h>     // open et ses flags
#include <dirent.h>    // les fonctions de manipulation de répertoires

void traitement_signal(int signal) {
    int status;
    pid_t pid;
    if (signal == SIGCHLD) {
        while ((pid = waitpid(-1, &status, WNOHANG|WUNTRACED|WCONTINUED)) > 0) {
            printf("Le processus fils %d a changé d'état: ", pid);
            if (WIFEXITED(status)){
                printf("il s'est terminé avec le code %i\n", WEXITSTATUS(status));
            } else if (WIFSIGNALED(status)) {
                printf("il s’est terminé (killed) par le signal %i\n", WTERMSIG(status));
            } else if (WIFSTOPPED(status)) {
                printf("il s'est suspendu par le signal\n");
            } else if (WIFCONTINUED(status)) {
                printf("il continue\n");
            }
        }
    }
}

void changer_rep(const char *nouv_rep){
    
    // le cas ou aucun argument nouv_rep n'est donné
    if (nouv_rep == NULL){
        char *rep_racine;
        rep_racine = getenv("HOME");
        if (rep_racine == NULL){
            perror("répertoire racine non existant");
            return;
        }
        if (chdir(rep_racine) == -1){
            perror("erreur chdir");
            return;
        }
    } else{
        if (chdir(nouv_rep) == -1){
            perror("erreur chdir");
            return;
        }
    }  
}

int main(void) {

    struct sigaction action_sig;
    action_sig.sa_handler = traitement_signal;
    sigemptyset(&action_sig.sa_mask);
    action_sig.sa_flags = SA_RESTART;

    if (sigaction(SIGCHLD, &action_sig, NULL) == -1) {
        perror("erreur de sigaction pour SIGCHLD");
        exit(EXIT_FAILURE);
    }
    
    //Etape 11.3
    sigset_t masque;
    sigemptyset(&masque); // notre set <- 0
    sigaddset(&masque, SIGINT); // ajouter Ctrl+C au set
    sigaddset(&masque, SIGTSTP); // ajouter Ctrl+Z  au set
    
    if (sigprocmask(SIG_BLOCK, &masque, NULL) == -1) {
        perror("erreur de sigprocmask");
        exit(EXIT_FAILURE);
    }

    bool fini= false;

    while (!fini) {
        printf("> ");
        struct cmdline *commande= readcmd();

        if (commande == NULL) {
            // commande == NULL -> erreur readcmd()
            perror("erreur lecture commande \n");
            exit(EXIT_FAILURE);
    
        } else {

            if (commande->err) {
                // commande->err != NULL -> commande->seq == NULL
                printf("erreur saisie de la commande : %s\n", commande->err);
        
            } else {

                /* Pour le moment le programme ne fait qu'afficher les commandes 
                   tapees et les affiche à l'écran. 
                   Cette partie est à modifier pour considérer l'exécution de ces
                   commandes 
                */
                int indexseq= 0;
                char **cmd;
                while ((cmd= commande->seq[indexseq])) {
                    if (cmd[0]) {
                        if (strcmp(cmd[0], "exit") == 0) {
                            fini= true;
                            printf("Au revoir ...\n");
                        }
                        // Etape 14
                        else if (strcmp(cmd[0], "cd") == 0) {
                            changer_rep(cmd[1]);
                        }
                        else {
                            printf("commande : ");
                            int indexcmd= 0;
                            while (cmd[indexcmd]) {
                                printf("%s ", cmd[indexcmd]);
                                indexcmd++;
                            }
                            printf("\n");
                            
                            // Etape 11.3
                            if (sigprocmask(SIG_BLOCK, &masque, NULL) == -1) {
                                perror("erreur de sigprocmask");
                                exit(EXIT_FAILURE);
                            }
                            
                            // création du processus fils
                            pid_t pid = fork();
                            if (pid == -1) {
                                printf("Erreur fork\n");
                                exit(1);
                            } else if (pid == 0) {
                                // processus fils
                                
                                // Etape 11.3
                                sigset_t masque_fils;
                                sigemptyset(&masque_fils);
                                
                                if (sigprocmask(SIG_SETMASK, &masque_fils, NULL) == -1) {
                                    perror("erreur démasquage signaux dans le fils");
                                    exit(EXIT_FAILURE);
                                }
                                
                                // Etape 12
                                // les processus en arrière plan doivent etre
                                // insensibles
                                if (commande->backgrounded != NULL) {
                                    // mettre les processus en arrière plan dans
                                    // un nouveau groupe
                                    if (setpgrp() == -1) {
                                        perror("erreur setpgrp");
                                        exit(EXIT_FAILURE);
                                    }
                                }
                                
                                // Etape 13
                                int entree, sortie;
                                
                                // Association de l'entrée standard de la commande
                                if (commande->in != NULL){
                                    if ((entree = open(commande->in, O_RDONLY)) == -1){
                                        perror("erreur open commande->in");
                                        exit(EXIT_FAILURE);
                                    }
                                    if ((dup2(entree, 0)) == -1){
                                        printf("erreur dup2 %s", commande->in);
                                        exit(EXIT_FAILURE);
                                    }
                                    close(entree);
                                }
                                
                                // Association de la sortie standard de la commande
                                if (commande->out != NULL){
                                    if ((sortie = open(commande->out, O_WRONLY|O_CREAT|O_TRUNC, 0644)) == -1){
                                        perror("erreur open commande->out");
                                        exit(EXIT_FAILURE);
                                    }
                                    if ((dup2(sortie, 1)) == -1){
                                        printf("erreur dup2 %s", commande->out);
                                        exit(EXIT_FAILURE);
                                    }
                                    close(sortie);
                                }
                                
                                if (execvp(cmd[0], cmd) == -1) {
                                    perror("Erreur execvp");
                                    exit(EXIT_FAILURE);
                                }
                                
                            } else {
                                // processus père
                                // wait(&status);  --avant on attendait toujours
                                                 // l'execution de la commande

                                if (commande->backgrounded == NULL) {
                                    // Commande en avant-plan
                                    // Option1: Il faut attendre la fin
                                    // waitpid(pid, &status, 0);
                                    
                                    // Option2: utiliser void pause()
                                    pause();
                                    
                                }
                            }
                        }

                        indexseq++;
                    }
                }
            }
        }
    }
    return EXIT_SUCCESS;
}
