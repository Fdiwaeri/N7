#include <stdio.h>
#include <stdlib.h>
#include "readcmd.h"
#include <stdbool.h>
#include <string.h>
#include <unistd.h>     // fork, getpid, getppid
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>    // signal et sigprocmask

void traitement_signal(int signal) {
    int status;
    pid_t pid;
    if (signal == SIGCHLD) {
        while ((pid = waitpid(-1, &status, WNOHANG|WUNTRACED|WCONTINUED)) > 0) {
            printf("Le processus fils %d a changé d'état: ", pid);
            if (WIFEXITED(status)){
                printf("il s'est terminé avec le code %i\n", WEXITSTATUS(status));
            } else if (WIFSIGNALED(status)) {
                printf("il s’est terminé (killed) par le signal %i\n", WTERMSIG(status));
            } else if (WIFSTOPPED(status)) {
                printf("il s'est suspendu par le signal\n");
            } else if (WIFCONTINUED(status)) {
                printf("il continue\n");
            }
        }
    }
    // Etape 11.1
    // else if (signal == SIGTSTP) {
    //    printf("\nsignal SIGTSTP reçu\n");
    //    printf("> ");
    //} else if (signal == SIGINT) {
    //    printf("\nsignal SIGINT reçu\n");
    //    printf("> ");
    //}
}

int main(void) {

    struct sigaction action_sig;
    action_sig.sa_handler = traitement_signal;
    sigemptyset(&action_sig.sa_mask);
    action_sig.sa_flags = SA_RESTART;

    if (sigaction(SIGCHLD, &action_sig, NULL) == -1) {
        perror("erreur de sigaction pour SIGCHLD");
        exit(EXIT_FAILURE);
    }

    // Etaoe 11.1
    // on effectue le traitement de sigaction aux signaux SIGINT et SIGTSTP
    // les 
    //if (sigaction(SIGINT, &action_sig, NULL) == -1) {
    //    perror("erreur de sigaction pour SIGINT");
    //    exit(EXIT_FAILURE);
    //}

    //if (sigaction(SIGTSTP, &action_sig, NULL) == -1) {
    //    perror("erreur de sigaction pour SIGTSTP");
    //    exit(EXIT_FAILURE);
    //}
    
    //Etape 11.3
    sigset_t masque;
    sigemptyset(&masque); // notre set <- 0
    sigaddset(&masque, SIGINT); // ajouter Ctrl+C au set
    sigaddset(&masque, SIGTSTP); // ajouter Ctrl+Z  au set
    
    if (sigprocmask(SIG_BLOCK, &masque, NULL) == -1) {
        perror("erreur de sigprocmask");
        exit(EXIT_FAILURE);
    }

    bool fini= false;

    while (!fini) {
        printf("> ");
        struct cmdline *commande= readcmd();

        if (commande == NULL) {
            // commande == NULL -> erreur readcmd()
            perror("erreur lecture commande \n");
            exit(EXIT_FAILURE);
    
        } else {

            if (commande->err) {
                // commande->err != NULL -> commande->seq == NULL
                printf("erreur saisie de la commande : %s\n", commande->err);
        
            } else {

                /* Pour le moment le programme ne fait qu'afficher les commandes 
                   tapees et les affiche à l'écran. 
                   Cette partie est à modifier pour considérer l'exécution de ces
                   commandes 
                */
                int indexseq= 0;
                char **cmd;
                while ((cmd= commande->seq[indexseq])) {
                    if (cmd[0]) {
                        if (strcmp(cmd[0], "exit") == 0) {
                            fini= true;
                            printf("Au revoir ...\n");
                        }
                        else {
                            printf("commande : ");
                            int indexcmd= 0;
                            while (cmd[indexcmd]) {
                                printf("%s ", cmd[indexcmd]);
                                indexcmd++;
                            }
                            printf("\n");

                            // Etape 11.2
                            //if (signal(SIGINT, SIG_IGN) == SIG_ERR) {
                            //    perror("erreur de signal pour SIGINT");
                            //    exit(EXIT_FAILURE);
                            //}

                            //if (signal(SIGTSTP, SIG_IGN) == SIG_ERR) {
                            //    perror("erreur de signal pour SIGTSTP");
                            //    exit(EXIT_FAILURE);
                            //}
                            
                            // Etape 11.3
                            if (sigprocmask(SIG_BLOCK, &masque, NULL) == -1) {
                                perror("erreur de sigprocmask");
                                exit(EXIT_FAILURE);
                            }
                            
                            // création du processus fils
                            pid_t pid = fork();
                            if (pid == -1) {
                                printf("Erreur fork\n");
                                exit(1);
                            } else if (pid == 0) {
                                // processus fils

                                // Etape 11.2
                                // pour que le traitement du père ne soit pas
                                // hérité par le fils, on le redéfinit pour un
                                // traitement par défaut
                                //if (signal(SIGINT, SIG_DFL) == SIG_ERR) {
                                //    perror("erreur de signal pour SIGINT");
                                //    exit(EXIT_FAILURE);
                                //}

                                //if (signal(SIGTSTP, SIG_DFL) == SIG_ERR) {
                                //    perror("erreur de signal pour SIGTSTP");
                                //    exit(EXIT_FAILURE);
                                //}
                                
                                
                                // Etape 11.3
                                sigset_t masque_fils;
                                sigemptyset(&masque_fils);
                                
                                if (sigprocmask(SIG_SETMASK, &masque_fils, NULL) == -1) {
                                    perror("erreur démasquage signaux dans le fils");
                                    exit(EXIT_FAILURE);
                                }
                                
                                // Etape 12
                                // les processus en arrière plan doivent etre
                                // insensibles
                                if (commande->backgrounded != NULL) {
                                    if (setpgrp() == -1) {
                                    perror("erreur setpgrp");
                                    exit(EXIT_FAILURE);
                                    }
                                }
                                
                                if (execvp(cmd[0], cmd) == -1) {
                                    perror("Erreur execvp");
                                    exit(EXIT_FAILURE);
                                }
                                
                            } else {
                                // processus père
                                // wait(&status);  --avant on attendait toujours
                                                 // l'execution de la commande

                                if (commande->backgrounded == NULL) {
                                    // Commande en avant-plan
                                    // Option1: Il faut attendre la fin
                                    // waitpid(pid, &status, 0);
                                    
                                    // Option2: utiliser void pause()
                                    pause();
                                    
                                }
                            }
                        }

                        indexseq++;
                    }
                }
            }
        }
    }
    return EXIT_SUCCESS;
}
